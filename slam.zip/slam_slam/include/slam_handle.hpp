/*
    Formula Student Driverless Project (FSD-Project).
    Copyright (c) 2020:
     - Atharva Pusalkar <atharvapusalkar18@gmail.com>

    FSD-Project is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    FSD-Project is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with FSD-Project.  If not, see <https://www.gnu.org/licenses/>.
*/

#ifndef ESTIMATION_SLAM_SLAM_HANDLE_HPP
#define ESTIMATION_SLAM_SLAM_HANDLE_HPP

#include <deque>

#include <ros/ros.h>
#include "fsd_common_msgs/ConeDetections.h"
#include "fsd_common_msgs/Cone.h"
#include "fsd_common_msgs/Map.h"
#include "fsd_common_msgs/CarState.h"
#include "geometry_msgs/Pose2D.h"
#include "slam.hpp"

#include "visualization_msgs/MarkerArray.h"
#include <visualization_msgs/Marker.h>

#include "eigen3/Eigen/Core"

namespace ns_slam {

class Command {
  public:
    Eigen::Vector3d v;
    Eigen::Vector2d p;
    double theta;
    double time_stamp;
};

class SlamHandle {

 public:
  // Constructor
  SlamHandle(ros::NodeHandle &nodeHandle);

  // Getters
  int getNodeRate() const;

  // Methods
  void loadParameters();
  void subscribeToTopics();
  void publishToTopics();
  void delayCompensate(const fsd_common_msgs::ConeDetections &cones);
  void sendMap();
  void sendState();
  void sendVisualization();

 private:
  ros::NodeHandle nodeHandle_;
  
  ros::Subscriber coneDetectionsSubscriber_;
  ros::Subscriber stateEstimateSubscriber_;

  ros::Publisher slamMapPublisher_;
  ros::Publisher slamMapRvizPublisher_;

  void coneDetectionsCallback(const fsd_common_msgs::ConeDetections &cones);
  void stateEstimateCallback(const fsd_common_msgs::CarState &state_estimate);

  std::string state_estimation_topic_name_;
  std::string cone_detections_topic_name_;
  std::string slam_map_topic_name_;
  std::string slam_map_rviz_topic_name_;
  int node_rate_;

  Slam slam_;
  fsd_common_msgs::ConeDetections cones_;
  fsd_common_msgs::CarState state_estimate_;
  fsd_common_msgs::Map slam_map_;
  fsd_common_msgs::CarState slam_state_;
  bool loop_closed_ = false;
  bool map_frozen_ = false;
  std::string current_state_;
  double previous_time_stamp_ = 0.0;
  ros::Time current_time_stamp_;

  int n_particles_;
  double mh_threshold_;

  Eigen::Vector3d z;
  Eigen::Matrix3d R;
  Eigen::Vector2d p;
  std::deque<Command> us;

  double vx_ = 0;
  double vy_ = 0;
  double theta_dt_ = 0;
  double steps_ = 0;

  bool detections_available_ = false;
};
}

#endif //ESTIMATION_SLAM_SLAM_HANDLE_HPP
