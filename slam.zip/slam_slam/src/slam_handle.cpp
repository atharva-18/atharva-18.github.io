/*
    Formula Student Driverless Project (FSD-Project).
    Copyright (c) 2020:
     - Atharva Pusalkar <atharvapusalkar18@gmail.com>

    FSD-Project is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    FSD-Project is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with FSD-Project.  If not, see <https://www.gnu.org/licenses/>.
*/

#include <ros/ros.h>
#include "slam_handle.hpp"

namespace ns_slam {

// Constructor
SlamHandle::SlamHandle(ros::NodeHandle &nodeHandle) :
    nodeHandle_(nodeHandle) {
  ROS_INFO("Constructing Handle");
  loadParameters();
  slam_.setParameters(n_particles_, mh_threshold_);
  subscribeToTopics();
  publishToTopics();

  current_state_ = "init";
}

// Getters
int SlamHandle::getNodeRate() const { return node_rate_; }

// Methods
void SlamHandle::loadParameters() {
  ROS_INFO("loading handle parameters");
  if (!nodeHandle_.param<std::string>("cone_detections_topic_name",
                                      cone_detections_topic_name_,
                                      "/perception/cone_detections")) {
    ROS_WARN_STREAM("Did not load cone_detections_topic_name. Standard value is: " << cone_detections_topic_name_);
  }
  if (!nodeHandle_.param<std::string>("slam_map_topic_name",
                                      slam_map_topic_name_,
                                      "/estimation/slam/map")) {
    ROS_WARN_STREAM("Did not load slam_map_topic_name. Standard value is: " << slam_map_topic_name_);
  }
  if (!nodeHandle_.param("node_rate", node_rate_, 1)) {
    ROS_WARN_STREAM("Did not load node_rate. Standard value is: " << node_rate_);
  }
  if (!nodeHandle_.param<std::string>("slam_map_rviz_topic_name", 
                                      slam_map_rviz_topic_name_, 
                                      "/estimation/visualization/map")) {
    ROS_WARN_STREAM("Did not load slam_map_rviz_topic_name. Standard value is: " << slam_map_rviz_topic_name_);
  }
  if (!nodeHandle_.param<std::string>("state_estimation_topic_name",
                                      state_estimation_topic_name_,
                                      "/estimation/state_estimation/state_estimate")) {
    ROS_WARN_STREAM("Did not load state_estimation_topic_name. Standard value is: " << state_estimation_topic_name_);
  }
  if (!nodeHandle_.param<int>("n_particles",
                               n_particles_,
                               100)) {
    ROS_WARN_STREAM("Did not load n_particles. Standard value is: " << n_particles_);
  }
  if (!nodeHandle_.param<double>("mh_threshold",
                                  mh_threshold_,
                                  1.0)) {
    ROS_WARN_STREAM("Did not load mh_threshold. Standard value is: " << mh_threshold_);
  }

  // Velocity covariance
  R << 1e-3, 0, 0,
       0, 1e-3, 0,
       0, 0, std::pow(0.0034, 2);
}

void SlamHandle::subscribeToTopics() {
  ROS_INFO("subscribe to topics");
  coneDetectionsSubscriber_ = nodeHandle_.subscribe(cone_detections_topic_name_, 1, &SlamHandle::coneDetectionsCallback, this);
  stateEstimateSubscriber_ = nodeHandle_.subscribe(state_estimation_topic_name_, 33, &SlamHandle::stateEstimateCallback, this);
}

void SlamHandle::publishToTopics() {
  ROS_INFO("publish to topics");
  slamMapPublisher_ = nodeHandle_.advertise<fsd_common_msgs::Map>(slam_map_topic_name_, 1);
  slamMapRvizPublisher_ = nodeHandle_.advertise<visualization_msgs::MarkerArray>(slam_map_rviz_topic_name_, 1, true);
}

void SlamHandle::sendMap() {
  slam_state_.car_state.x = slam_.getState().x;
  slam_state_.car_state.y = slam_.getState().y;
  slam_state_.car_state.theta = slam_.getState().theta;
  slam_state_.car_state_dt = state_estimate_.car_state_dt;

  slam_map_.cone_blue = slam_.getMap().cone_blue;
  slam_map_.cone_yellow = slam_.getMap().cone_yellow;
  slam_map_.cone_orange = slam_.getMap().cone_orange;
  slam_map_.car_state = slam_state_;
  slam_map_.header.stamp = current_time_stamp_;
  slamMapPublisher_.publish(slam_map_);
  ROS_INFO("SLAM map sent");
}

void SlamHandle::delayCompensate(const fsd_common_msgs::ConeDetections &cones) {
  double time_stamp = cones.header.stamp.toSec();

  // Find closest state estimate to detection timestamp
  auto it = std::upper_bound(us.begin(), us.end(), time_stamp, [](double time_stamp, const Command &a) {
                              return time_stamp < a.time_stamp;
                            });

  if(it == us.end())
    it--;

  int i_d = std::distance(us.begin(), it);
   
  // Queue is empty
  if(i_d == us.size())
    return;

  cones_.cone_detections.clear();
  for(int i = 0; i < cones.cone_detections.size(); i++) {
    fsd_common_msgs::Cone cone;

    // Delay compensation
    const double c = std::cos(us[i_d].theta);
    const double s = std::sin(us[i_d].theta);

    const double dt = cones.header.stamp.toSec() - us[i_d].time_stamp;
    double x_car_comp = us[i_d].p(0) + us[i_d].v(0) * std::cos(us[i_d].theta) * dt;
    double y_car_comp = us[i_d].p(1) + us[i_d].v(1) * std::sin(us[i_d].theta) * dt;

    double x_cone = (cones.cone_detections[i].position.x * c - cones.cone_detections[i].position.y * s) + x_car_comp;
    double y_cone = (cones.cone_detections[i].position.x * s + cones.cone_detections[i].position.y * c) + y_car_comp;

    double r = std::hypot(x_cone - us.back().p(0), y_cone - us.back().p(1));
    double b = std::atan2(y_cone - us.back().p(1), x_cone - us.back().p(0));

    double x_cone_comp = r * std::cos(b);
    double y_cone_comp = r * std::sin(b);

    cone.position.x = x_cone_comp;
    cone.position.y = y_cone_comp;
    cone.color.data = cones.cone_detections[i].color.data;
    cones_.cone_detections.push_back(cone);
  }
}

void SlamHandle::coneDetectionsCallback(const fsd_common_msgs::ConeDetections &cones) {
  if(cones.header.stamp.toSec() < us.front().time_stamp) // Cones observed before state estimate
    return;

  ROS_INFO("Updating map with cones");

  loop_closed_ = slam_.getLoopState();

  const double dist = std::sqrt(std::pow(slam_state_.car_state.x, 2) + std::pow(slam_state_.car_state.y, 2));

  // State machine
  if(current_state_ == "init" && !loop_closed_ && dist > 3.0) {
    current_state_ = "slam";
  }
  else if(current_state_ == "slam" && loop_closed_) {
    current_state_ = "localization";
    map_frozen_ = true;
  }

  delayCompensate(cones);

  // Get average velocity over dt
  z << vx_ / (steps_ * 1.0), vy_ / (steps_ * 1.0), theta_dt_ / (steps_ * 1.0);

  if(previous_time_stamp_ - 0.0 < 0.0001)
    previous_time_stamp_ = us.front().time_stamp;

  const double dt = current_time_stamp_.toSec() - previous_time_stamp_;

  slam_.predictParticles(z, R, dt);
  slam_.updateLandmarks(cones_, map_frozen_);
  slam_.resample();
  slam_.calcFinalState();
  slam_.createMap();
  
  sendMap();
  sendVisualization();

  steps_ = 0;
  previous_time_stamp_ = current_time_stamp_.toSec();
}

void SlamHandle::stateEstimateCallback(const fsd_common_msgs::CarState &state_estimate) {
  state_estimate_.car_state_dt = state_estimate.car_state_dt;
  state_estimate_.header.stamp = state_estimate.header.stamp;
  current_time_stamp_ = state_estimate.header.stamp;

  // Transform velocity from body to map frame
  double c = std::cos(state_estimate_.car_state.theta);
  double s = std::sin(state_estimate_.car_state.theta);

  z << state_estimate_.car_state_dt.car_state_dt.x * c - state_estimate_.car_state_dt.car_state_dt.y * s, 
       state_estimate_.car_state_dt.car_state_dt.x * s + state_estimate_.car_state_dt.car_state_dt.y * c,
       state_estimate_.car_state_dt.car_state_dt.theta;

  p << state_estimate.car_state.x, state_estimate.car_state.y;

  Command u;
  u.v = z;
  u.p = p;
  u.theta = state_estimate.car_state.theta;
  u.time_stamp = state_estimate.header.stamp.toSec();
  us.push_back(u);

  if(steps_ == 0) {
    vx_ = z(0);
    vy_ = z(1);
    theta_dt_ = z(2);
  }else {
    vx_ += z(0);
    vy_ += z(1);
    theta_dt_ += z(2);
  }

  steps_++;

  if(us.size() > 34)
    us.pop_front();
};

void SlamHandle::sendVisualization() {
  visualization_msgs::MarkerArray markers;
  visualization_msgs::Marker marker;

  marker.pose.orientation.w = 1.0;
  marker.type               = visualization_msgs::Marker::MESH_RESOURCE;
  marker.action             = visualization_msgs::Marker::ADD;
  marker.id                 = 1;
  marker.scale.x            = 1.0;
  marker.scale.y            = 1.0;
  marker.scale.z            = 1.0;
  marker.pose.orientation.x = 0.0;
  marker.pose.orientation.y = 0.0;
  marker.pose.orientation.z = 0.0;
  marker.pose.orientation.w = 1.0;
  marker.header.stamp       = ros::Time::now();
  marker.header.frame_id    = "map";
  marker.color.a            = 1.0;
  
  int id_cnt = 2;

  marker.color.r       = 0.0;
  marker.color.g       = 0.0;
  marker.color.b       = 1.0;
  for(int i = 0; i < slam_map_.cone_blue.size();i++) {
    marker.id = id_cnt;
    marker.pose.position.x = slam_map_.cone_blue[i].position.x;
    marker.pose.position.y = slam_map_.cone_blue[i].position.y;
    marker.mesh_resource = "package://slam_slam/rviz/meshes/cone/cone_blue.dae";
    markers.markers.push_back(marker);
    id_cnt++;
  }

  marker.color.r       = 1.0;
  marker.color.g       = 1.0;
  marker.color.b       = 0.0;
  for(int i = 0; i < slam_map_.cone_yellow.size();i++) {
    marker.id = id_cnt;
    marker.pose.position.x = slam_map_.cone_yellow[i].position.x;
    marker.pose.position.y = slam_map_.cone_yellow[i].position.y;
    marker.mesh_resource = "package://slam_slam/rviz/meshes/cone/cone_yellow.dae";
    markers.markers.push_back(marker);
    id_cnt++;
  }

  marker.color.r       = 1.0;
  marker.color.g       = static_cast<float>(165.0 / 255.0);
  marker.color.b       = 0.0;
  for(int i = 0; i < slam_map_.cone_orange.size();i++) {
    marker.id = id_cnt;
    marker.pose.position.x = slam_map_.cone_orange[i].position.x;
    marker.pose.position.y = slam_map_.cone_orange[i].position.y;
    marker.mesh_resource = "package://slam_slam/rviz/meshes/cone/cone_orange.dae";
    markers.markers.push_back(marker);
    id_cnt++;
  }

  slamMapRvizPublisher_.publish(markers);

  ROS_INFO("SLAM visualization sent.");

}

}
