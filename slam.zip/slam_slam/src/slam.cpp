/*
    Formula Student Driverless Project (FSD-Project).
    Copyright (c) 2020:
     - Atharva Pusalkar <atharvapusalkar18@gmail.com>

    FSD-Project is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    FSD-Project is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with FSD-Project.  If not, see <https://www.gnu.org/licenses/>.
*/

#include <ros/ros.h>
#include "slam.hpp"

#include <sstream>
#include <random>

#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>
#include <eigen3/Eigen/Cholesky>

namespace ns_slam {

double pi_2_pi(double angle) {
  return std::fmod(std::fmod((angle)+M_PI, 2*M_PI)-2*M_PI, 2*M_PI)+M_PI;
};

Jacobians computeJacobians(Particle *particle, Eigen::Vector2d xf, Eigen::Matrix2d Pf, Eigen::Matrix2d Q_cov) {
  Jacobians j;
  j.Hv = Eigen::MatrixXd(2,3);

  double dx = xf(0) - particle->x;
  double dy = xf(1) - particle->y;
  double d2 = std::pow(dx, 2) + std::pow(dy, 2);
  double d = std::sqrt(d2);

  j.zp << d, pi_2_pi(std::atan2(dy, dx) - particle->yaw);

  j.Hv << -dx / d, -dy / d, 0.0,
           dy / d2, -dx / d2, -1.0;

  j.Hf << dx / d, dy / d,
          -dy / d2, dx / d2;

  j.Sf = j.Hf * Pf * j.Hf.transpose() + Q_cov;
  return j;
}

// Constructor
Landmark::Landmark(Eigen::Vector2d z, Eigen::Matrix2d Q, std::string color_, Particle *particle) {
  double r = z(0);
  double b = z(1);
  
  double c = std::cos(pi_2_pi(particle->yaw + b));
  double s = std::sin(pi_2_pi(particle->yaw + b));
  this->x[0] = particle->x + r * c;
  this->x[1] = particle->y + r * s;
  
  double dx = r * c;
  double dy = r * s;
  double d2 = std::pow(dx, 2) + std::pow(dy, 2);
  double d = std::sqrt(d2);

  Eigen::Matrix2d Gz;
  Gz << dx / d, dy / d,
        -dy / d2, dx / d2;
  
  this->P = Gz.inverse() * Q * Gz.transpose().inverse();

  this->color = color_;
}

// Multivariate Gaussian Update from measurements
void Landmark::update(Eigen::Vector2d z, Eigen::Matrix2d Q, std::string color_, Particle *particle) {  
  Jacobians j = computeJacobians(particle, this->x, this->P, Q);

  Eigen::Vector2d dz;
  dz << z(0) - j.zp(0), pi_2_pi(z(1) - j.zp(1));

  auto Pht = this->P * j.Hf.transpose();
  auto Sf = j.Hf * Pht + Q;
  auto Sfa = (Sf + Sf.transpose()) * 0.5;
  Eigen::Matrix2d Schol(Sfa.llt().matrixL().transpose());
  auto Sinv = Schol.inverse();
  auto W1 = Pht * Sinv;
  auto W = W1 * Sinv.transpose();

  this->x = this->x + W * dz;
  this->x = this->x.transpose();
  this->P = this->P - W1 * W1.transpose();

  this->color = color_;
}

// Get PDF for a given z value from MVN
double Landmark::pdf(const Eigen::Vector2d &z) const {
  double n = z.rows();
  double sqrt2pi = std::sqrt(2 * M_PI);
  double quadform  = (z - this->x).transpose() * P.inverse() * (z - this->x);
  double norm = std::pow(sqrt2pi, - n) *
                std::pow(this->P.determinant(), -0.5);

  return norm * exp(-0.5 * quadform);
}

// Compute Mahalanobis distance between a point and a multivariate distribution
double Landmark::mahalanobis(const Eigen::Vector2d &z) const {
  return (this->x - z).transpose() * this->P * (this->x - z);
}

// Constructor
Particle::Particle(int n_particles) {
  this->w = 1.0 / n_particles;
  this->x = 0.0;
  this->y = 0.0;
  this->yaw = 0.0;
  this->P << 3, 0, 0,
             0, 3, 0,
             0, 0, 3;
}

void Particle::predict(Eigen::Vector3d u, double dt) {
  // ROS_WARN_STREAM("Vx: " << u(0) << " Vy: " << u(1) << " dth: " << u(2));
  this->x = this->x + u(0) * dt;
  this->y = this->y + u(1) * dt;
  this->yaw = this->yaw + u(2) * dt;

  this->yaw = pi_2_pi(this->yaw);

  // ROS_WARN_STREAM("x: " << this-> x << " y: " << this-> y << " theta: " << this->yaw);
}

double Particle::computeWeight(int id, Eigen::Vector2d z, Eigen::Matrix2d Q) {
  double weight;
  
  auto xf = this->landmarks[id].x;
  auto Pf = this->landmarks[id].P;

  Jacobians j = computeJacobians(this, xf, Pf, Q);

  Eigen::Vector2d dz;
  dz << z(0) - j.zp(0), pi_2_pi(z(1) - j.zp(1));
  
  Eigen::Matrix2d invS;
  
  try {
    invS = j.Sf.inverse();
  }catch(...) {
    return 1.0;
  }

  double num = std::exp(-0.5 * dz.transpose() * invS * dz);
  double den = 2.0 * M_PI * std::sqrt(j.Sf.determinant());

  if(std::isinf(num))
    return 1.0;

  weight = num / den;

  return weight;
}

void Particle::proposalSampling(int id, Eigen::Vector2d z, Eigen::Matrix2d Q) {
  auto xf = this->landmarks[id].x;
  auto Pf = this->landmarks[id].P;

  Jacobians j = computeJacobians(this, xf, Pf, Q);

  Eigen::Matrix2d Sinv = j.Sf.inverse();

  Eigen::Vector2d dz;
  dz << z(0) - j.zp(0), pi_2_pi(z(1) - j.zp(1));

  auto Pi = this->P.inverse();
  
  this->P = (j.Hv.transpose() * Sinv * j.Hv + Pi).inverse();
  auto dx = this->P * j.Hv.transpose() * Sinv * dz;

  this->x += dx[0];
  this->y += dx[1];
  this->yaw += dx[2];

}  

// Constructor
Slam::Slam() {
  initializeState();
  best_id_ = 0;
};

// Getters
fsd_common_msgs::Map Slam::getMap() const { return cone_map_; }
geometry_msgs::Pose2D Slam::getState() const { return slam_state_; }

void Slam::setParameters(int n_particles, double mh_threshold) {
  n_particles_ = n_particles;
  n_resample_ = n_particles_ / 1.5;
  mh_threshold_ = mh_threshold;

  for(int i = 0; i < n_particles_;i++) {
    particles_.push_back(Particle(n_particles_));
  }
  ROS_WARN_STREAM("No. of particles: " << particles_.size());
}

void Slam::initializeState() {
  slam_state_.x = 0;
  slam_state_.y = 0;
  slam_state_.theta = 0;

}

void Slam::predictParticles(Eigen::Vector3d u, Eigen::Matrix3d R, double dt) {
  std::random_device rd;
  std::mt19937 e2(rd());
  std::normal_distribution<> dist(0, 1.0);

  for(auto &particle:particles_) {
    Eigen::MatrixXd noise(1, 3);
    noise(0,0) = dist(e2);
    noise(0,1) = dist(e2);
    noise(0,2) = dist(e2);
    Eigen::Vector3d ud = u + (noise * R.cwiseSqrt()).transpose();
  
    // ROS_WARN_STREAM("Particle #" << counts);
    particle.predict(ud, dt);
  }
  
}

void Slam::normalizeWeight() {
  double sum_w = 0.0;
  
  for(auto &particle:particles_)
    sum_w += particle.w;

  try {
    for(auto &particle:particles_)
      particle.w /= sum_w;
  }catch(...) { // Zero division error
    for(auto &particle:particles_)
      particle.w = 1.0 / n_particles_;
  }
}

void Slam::resample() {
  normalizeWeight();

  Eigen::VectorXd pw(particles_.size());

  for(int i = 0; i < particles_.size(); i++) {
    pw(i) = particles_[i].w;
  }
  
  double n_eff = 1.0 / pw.dot(pw.transpose());

  if(n_eff < n_resample_) {
    
    std::random_device rd;
    std::mt19937 gen(rd());
    std::vector<double> weights(n_particles_);
    
    double sum = 0.0;
    for(int i = 0; i < n_particles_; i++) {
      weights[i] = particles_[i].w;
      sum += weights[i];
    }

    for(int i = 0; i < n_particles_; i++) {
      particles_[i].w = particles_[i].w/sum;
    }

    std::discrete_distribution<> d(weights.begin(), weights.end());
    std::vector<Particle> resampParticle;
  
    for (unsigned int i = 0; i < n_particles_; i++) {
      int idx = d(gen);
      resampParticle.push_back(particles_[idx]);
    }

    particles_ = resampParticle;

  }
  
}

void Slam::updateLandmarks(const fsd_common_msgs::ConeDetections &cones, bool frozen_update) {
  for(int i = 0; i < cones.cone_detections.size(); i++) {
    for(auto &particle:particles_) {
      Eigen::Vector2d z;

      // x_cone_world = x_cone * cos(yaw) - y_cone * sin(yaw) + x_car
      // y_cone_world = x_cone * sin(yaw) + y_cone * cos(yaw) + y_car
      const double s = std::sin(particle.yaw); 
      const double c = std::cos(particle.yaw);

      // Transform from robot to world frame
      z << (cones.cone_detections[i].position.x * c - cones.cone_detections[i].position.y * s) + particle.x, // Calculate Landmark coordinates 
          (cones.cone_detections[i].position.x * s + cones.cone_detections[i].position.y * c) + particle.y;

      Eigen::Matrix2d Q;
      Q << 1.0, 0,
           0, std::pow(0.174533, 2);

      // Find most probable Landmark
      const auto p_it = std::min_element(particle.landmarks.begin(), particle.landmarks.end(), 
                                        [&](const Landmark &a, const Landmark &b) {
                                            double da = std::hypot(a.x[0] - z(0), a.x[1] - z(1));
                                            double db = std::hypot(b.x[0] - z(0), b.x[1] - z(1));
                                            // return a.mahalanobis(z) < b.mahalanobis(z);
                                            return da < db;
                                        });
      // Index
      const auto p_i = std::distance(particle.landmarks.begin(), p_it);

      if(p_i == particle.landmarks.size()) {
        // Add new cone to empty map
        double r = std::hypot(cones.cone_detections[i].position.x, cones.cone_detections[i].position.y);
        double b = pi_2_pi(std::atan2(cones.cone_detections[i].position.y, cones.cone_detections[i].position.x));
        z(0) = r;
        z(1) = b;
        Landmark new_landmark(z, Q, cones.cone_detections[i].color.data, &particle);
        particle.landmarks.push_back(new_landmark);
      }else if(std::hypot(particle.landmarks[p_i].x[0] - z(0), particle.landmarks[p_i].x[1] - z(1)) > 1.4 && !frozen_update) {
        // Probablity is too low
        double r = std::hypot(cones.cone_detections[i].position.x, cones.cone_detections[i].position.y);
        double b = pi_2_pi(std::atan2(cones.cone_detections[i].position.y, cones.cone_detections[i].position.x));
        z(0) = r;
        z(1) = b;
        
        // Add new cone to map
        Landmark new_landmark(z, Q, cones.cone_detections[i].color.data, &particle);
        particle.landmarks.push_back(new_landmark);
      }else {
        // Update cone position
        double r = std::hypot(cones.cone_detections[i].position.x, cones.cone_detections[i].position.y);
        double b = pi_2_pi(std::atan2(cones.cone_detections[i].position.y, cones.cone_detections[i].position.x));
        z(0) = r;
        z(1) = b;
        
        particle.w *= particle.computeWeight(p_i, z, Q);
        particle.landmarks[p_i].update(z, Q, cones.cone_detections[i].color.data, &particle);
        particle.proposalSampling(p_i, z, Q);
      }
    }
  }
}

void Slam::calcFinalState() {
  normalizeWeight();
  slam_state_.x = 0.0;
  slam_state_.y = 0.0;
  slam_state_.theta = 0.0;

  for(int i = 0; i < particles_.size(); i++) {
    slam_state_.x += (particles_[i].x * particles_[i].w);
    slam_state_.y += (particles_[i].y * particles_[i].w);
    slam_state_.theta += (particles_[i].yaw * particles_[i].w);
  }

  slam_state_.theta = pi_2_pi(slam_state_.theta);
}

void Slam::createMap() {
  cone_map_.cone_blue.clear();
  cone_map_.cone_yellow.clear();
  cone_map_.cone_orange.clear();

  double max_w = std::numeric_limits<double>::min();
  int id_cnt = 0;

  for(auto &particle:particles_) {
    if(particle.w > max_w) {
      max_w = particle.w;
      best_id_ = id_cnt; 
    }
    id_cnt++;
  }
  
  for(size_t i = 0;i < particles_[best_id_].landmarks.size(); i++) {
    fsd_common_msgs::Cone cone_;

    cone_.position.x = particles_[best_id_].landmarks[i].x[0];
    cone_.position.y = particles_[best_id_].landmarks[i].x[1];
    cone_.color.data = particles_[best_id_].landmarks[i].color;

    if(cone_.color.data == "b")
      cone_map_.cone_blue.push_back(cone_);
    else if(cone_.color.data == "y")
      cone_map_.cone_yellow.push_back(cone_);
    else if(cone_.color.data == "o")
      cone_map_.cone_orange.push_back(cone_);
  }

  ROS_WARN_STREAM("Map size is " <<  (int) (cone_map_.cone_blue.size()
                                    + cone_map_.cone_yellow.size() 
                                    + cone_map_.cone_orange.size()));
}

void Slam::calculateState(const fsd_common_msgs::CarStateDt &velocity) {
  slam_state_.x += velocity.car_state_dt.x;
  slam_state_.y += velocity.car_state_dt.y;
  slam_state_.theta += velocity.car_state_dt.theta;
}

bool Slam::getLoopState() {
  // const auto std_dev_xy = std::sqrt(P(0) + P(3));
  const auto std_dev_xy = 0.9;

  const auto dist = std::sqrt(std::pow(slam_state_.x, 2) + std::pow(slam_state_.y, 2));

  // Normalize yaw angle between -PI and +PI
  slam_state_.theta = pi_2_pi(slam_state_.theta);

  /*
  * Lap closure is detected with three basic rules. 
  * First, the sample standard deviation of the position, has to be below a threshold. 
  * Second, the cars current heading has to be roughly equal to the heading at the beginning of the race 
  * and third, the car must be close to the origin.
  */
  if(dist < 1.0 && std_dev_xy < 1.0 && slam_state_.theta < 0.69813 && slam_state_.theta > -0.69813)
    return true; // Loop is closed
  
  return false;
}

}
