/*
    Formula Student Driverless Project (FSD-Project).
    Copyright (c) 2020:
     - Atharva Pusalkar <atharvapusalkar18@gmail.com>

    FSD-Project is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    FSD-Project is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with FSD-Project.  If not, see <https://www.gnu.org/licenses/>.
*/

#include <ros/ros.h>
#include "cone_detector.hpp"
#include <sstream>

namespace ns_cone_detector {

  void ConeDescriptor::calculate() {
    count = cloud->size();
    Point sum, sum2;
    sum.x = 0; sum.y = 0; sum.z = 0;
    sum2.x = 0; sum2.y = 0; sum2.z = 0;
    sum.intensity = 0; sum2.intensity = 0;
    for(auto &pt : (*cloud)){
      sum.x += pt.x; sum.y += pt.y; sum.z += pt.z;
      sum.intensity += pt.intensity;
      sum2.x += pt.x*pt.x; sum2.y += pt.y*pt.y; sum2.z += pt.z*pt.z;
      sum2.intensity += pt.intensity*pt.intensity;
    }
    mean.x = sum.x/count;
    mean.y = sum.y/count;
    mean.z = sum.z/count;
    mean.intensity = sum.intensity/count;
    stddev.x = sqrtf(sum2.x/count-mean.x*mean.x);
    stddev.y = sqrtf(sum2.y/count-mean.y*mean.y);
    stddev.z = sqrtf(sum2.z/count-mean.z*mean.z);
    stddev.intensity = sqrtf(sum2.intensity/count-mean.intensity*mean.intensity);
    radius = sqrtf(stddev.x*stddev.x+stddev.y*stddev.y+stddev.z*stddev.z);
    valid = radius < 0.3 && stddev.x < 0.2 && stddev.y < 0.2 && stddev.z < 0.2;
  }

  // Constructor
  Visualizer::Visualizer() {
    viewer = boost::shared_ptr<pcl::visualization::PCLVisualizer>(new pcl::visualization::PCLVisualizer("3d visualizer"));
    viewer->initCameraParameters ();
    viewer->setCameraPosition (/*pos_xyz*/0, 20, 20, /*view_xyz*/0, 0, -2, /*up_xyz*/0, -1, -1);

    viewer->createViewPort(0.0, 0.0, 0.5, 1.0, v1);
    viewer->setBackgroundColor (0, 0, 0, v1);
    viewer->addText(c1, 10, 10, "v1 text", v1);

    viewer->createViewPort(0.5, 0.0, 1.0, 1.0, v2);
    viewer->setBackgroundColor (0.0, 0.0, 0.0, v2);
    viewer->addText(c2, 10, 10, "v2 text", v2);

    viewer->setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, point_size, c1);
    viewer->setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, point_size, c2);
    viewer->addCoordinateSystem (1.0);
  }

  void Visualizer::draw(Cloud::ConstPtr cloud, Cloud::ConstPtr cloud_out, Segmentation &segm, pcl::ModelCoefficients::Ptr plane_coefs, std::vector<ConeDescriptor> &cones) {

    CloudC::Ptr cloud_color(new CloudC);
    cloud_color->resize(cloud_out->size());
    for(int n = 0; n < cloud_out->size(); n++){
      auto &c = (*cloud_color)[n];
      auto &p = (*cloud_out)[n];
      c.x = p.x; c.y = p.y; c.z = p.z;
      const u_char * rgb = PointClasses::colors[segm[n]];
      c.r = rgb[0]; c.g = rgb[1]; c.b = rgb[2];
    }

    pcl::visualization::PointCloudColorHandlerGenericField<Point> intensity(cloud, "intensity");
    pcl::visualization::PointCloudColorHandlerRGBField<PointC> segmanetation(cloud_color);

    if( !viewer->updatePointCloud<Point>( cloud, intensity, c1) ){
      viewer->addPointCloud<Point> (cloud, intensity, c1, v1 );
    }
    if( !viewer->updatePointCloud<PointC>( cloud_color,segmanetation, c2) ){
      viewer->addPointCloud<PointC>( cloud_color,segmanetation, c2, v2 );
    }
    
    viewer->setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, point_size, c1);
    viewer->setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, point_size, c2);

    viewer->removeAllShapes();
    viewer->addPlane(*plane_coefs, "plane",v2);

    int n = 0;
    for(auto& cone: cones){
      if(cone.valid){
        std::string name = "sphere_" + std::to_string(n++);
        viewer->addSphere(cone.mean, 0.3, 1.0, 0.0, 0.0, name, v2);
      }
    }

    viewer->spinOnce(1);
  }

  OutlierFilter::OutlierFilter() {
    params = Params();
  }

  void OutlierFilter::run(const sensor_msgs::PointCloud2::ConstPtr& msg) {
    //ROS_INFO("size: %d, point_step: %d, row_step: %d, width: %d, height: %d]", (int)msg->data.size(), (int)msg->point_step, (int)msg->row_step, (int)msg->width, (int)msg->height);
    Cloud::Ptr cloud_in(new Cloud), cloud_out(new Cloud);

    pcl::fromROSMsg(*msg, *cloud_in);

    // filter
    outlier_filter_impl(cloud_in, cloud_out);

    // display


  }

  void OutlierFilter::outlier_filter_impl(Cloud::Ptr &cloud_in, Cloud::Ptr &cloud_out) {

    { // remove distant object
      pcl::PassThrough<Point> pass_z;
      pass_z.setInputCloud(cloud_in);
      pass_z.setFilterFieldName("z");
      pass_z.setFilterLimits(-1.0f, 2.0f);
      pass_z.filter(*cloud_out);
    }

    pcl::ModelCoefficients::Ptr plane_coefs (new pcl::ModelCoefficients);
    { // RANSAC plane estimation
      pcl::PointIndices::Ptr inliers(new pcl::PointIndices);

      // Create the segmentation object
      pcl::SACSegmentation<Point> seg;
      seg.setOptimizeCoefficients(true);
      seg.setModelType(pcl::SACMODEL_PLANE);
      seg.setMethodType(pcl::SAC_RANSAC);
      seg.setDistanceThreshold(0.01);
      // at most 15 degrees from z axis
      seg.setAxis(Eigen::Vector3f(0, 0, 1));
      seg.setEpsAngle(pcl::deg2rad(15.0));

      seg.setInputCloud(cloud_out);
      seg.segment(*inliers, *plane_coefs);
    }

    Segmentation segm(cloud_out->size());
    Cloud::Ptr cloud_cones(new Cloud);
    cloud_cones->reserve(cloud_out->size());
    { // segment the cones
      for (int n = 0; n < cloud_out->size(); n++) {
        Point &pt = (*cloud_out)[n];
        float height = (float) pcl::pointToPlaneDistanceSigned(pt,plane_coefs->values[0],
                                                                  plane_coefs->values[1],
                                                                  plane_coefs->values[2],
                                                                  plane_coefs->values[3]);
        float distance = sqrtf(pt.x * pt.x + pt.y * pt.y + pt.z * pt.z);

        auto &s = segm[n];
        if ((height < 0.01) || (distance < 7.0 & height < 0.03))
          s = PointClasses::ground;
        else if (distance > 40.0) {
          s = PointClasses::too_far;
        } else if (height > 0.5) {
          s = PointClasses::too_high;
        } else {
          s = PointClasses::inlier;
          cloud_cones->push_back(pt);
        }
      }
    }

    cones.clear();
    SegmentConeInstances(cloud_cones, cones);

    vis.draw(cloud_in, cloud_out, segm, plane_coefs, cones);
  }

  void OutlierFilter::SegmentConeInstances(Cloud::Ptr cloud_cones, std::vector<ConeDescriptor> &cones) {

    double cluster_tolerance;
    int min_cluster_size, max_cluster_size;
    ros::param::param("ec_cluster_tolerance", cluster_tolerance, 0.7);
    ros::param::param("ec_min_cluster_size", min_cluster_size, 4);
    ros::param::param("ec_max_cluster_size", max_cluster_size, 1000);

    std::vector<pcl::PointIndices> object_indices;
    pcl::EuclideanClusterExtraction<Point> euclid;
    euclid.setInputCloud(cloud_cones);
    euclid.setClusterTolerance(cluster_tolerance);
    euclid.setMinClusterSize(min_cluster_size);
    euclid.setMaxClusterSize(max_cluster_size);
    euclid.extract(object_indices);

    pcl::ExtractIndices<Point> extract;
    extract.setInputCloud(cloud_cones);

    cones.reserve(object_indices.size());
    size_t min_size = std::numeric_limits<size_t>::max();
    size_t max_size = std::numeric_limits<size_t>::min();
    pcl::PointIndices::Ptr object_ptr(new pcl::PointIndices);
    for (auto& object: object_indices) {
      size_t cluster_size = object.indices.size();
      if (cluster_size < min_size) {
        min_size = cluster_size;
      }
      if (cluster_size > max_size) {
         max_size = cluster_size;
      }
      ConeDescriptor cone;
      *object_ptr = object;
      extract.setIndices(object_ptr);
      extract.filter(*cone.cloud);
      cone.calculate();
      cones.push_back(cone);
    }
  }

  // Constructor
  ConeDetector::ConeDetector() {
    filter = OutlierFilter();  
  };

  // Getters
  fsd_common_msgs::ConeDetections ConeDetector::getConeDetections() const { return coneDetections_;}

  void ConeDetector::runAlgorithm(const sensor_msgs::PointCloud2::ConstPtr& msg) {
    filter.run(msg);
    createConeDetections();
  }

  void ConeDetector::createConeDetections() {
    std::vector<fsd_common_msgs::Cone> cones;
    fsd_common_msgs::Cone cone;

    for (auto& filter_cone: filter.cones) {
      if(filter_cone.valid) {
        cone.position.x = filter_cone.mean.x;
        cone.position.y = filter_cone.mean.y;
        cone.color.data = "u";
        cones.push_back(cone); 
      }
    }
    coneDetections_.cone_detections = cones;
  }

}
