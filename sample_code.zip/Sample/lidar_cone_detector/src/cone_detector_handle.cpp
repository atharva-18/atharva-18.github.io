/*
    Formula Student Driverless Project (FSD-Project).
    Copyright (c) 2020:
     - Atharva Pusalkar <atharvapusalkar18@gmail.com>

    FSD-Project is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    FSD-Project is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with FSD-Project.  If not, see <https://www.gnu.org/licenses/>.
*/

#include <ros/ros.h>
#include "cone_detector_handle.hpp"

namespace ns_cone_detector {

// Constructor
ConeDetectorHandle::ConeDetectorHandle(ros::NodeHandle &nodeHandle) :
    nodeHandle_(nodeHandle) {
  ROS_INFO("Constructing Handle");
  loadParameters();
  publishToTopics();
  subscribeToTopics();
  point_cloud_available = false;
}

// Getters
int ConeDetectorHandle::getNodeRate() const { return node_rate_; }

// Methods
void ConeDetectorHandle::loadParameters() {
  ROS_INFO("loading handle parameters");
  if (!nodeHandle_.param<std::string>("cone_detections_topic_name",
                                      cone_detections_topic_name_,
                                      "/perception/cone_detections")) {
    ROS_WARN_STREAM("Did not load cone_detections_topic_name. Standard value is: " << cone_detections_topic_name_);
  }
  if (!nodeHandle_.param<std::string>("point_cloud_topic_name",
                                      point_cloud_topic_name_,
                                      "/velodyne_points")) {
    ROS_WARN_STREAM("Did not load point_cloud_topic_name. Standard value is: " << point_cloud_topic_name_);
  }
  if (!nodeHandle_.param<std::string>("marker_topic_name",
                                      marker_topic_name_,
                                      "/perception/lidar/cones")) {
    ROS_WARN_STREAM("Did not load marker_topic_name. Standard value is: " << marker_topic_name_);
  }
  if (!nodeHandle_.param("node_rate", node_rate_, 10)) {
    ROS_WARN_STREAM("Did not load node_rate. Standard value is: " << node_rate_);
  }
}

void ConeDetectorHandle::publishToTopics() {
  ROS_INFO("publish to topics");
  coneDetectionsPublisher = nodeHandle_.advertise<fsd_common_msgs::ConeDetections>(cone_detections_topic_name_, 1);
  coneMarkersPublisher = nodeHandle_.advertise<visualization_msgs::Marker>(marker_topic_name_, 1);
}

void ConeDetectorHandle::subscribeToTopics() {
  ROS_INFO("subscribe to topics");
  pointCloudSubscriber = nodeHandle_.subscribe(point_cloud_topic_name_, 1, &ConeDetectorHandle::pointCloudCallback, this);
}

void ConeDetectorHandle::pointCloudCallback(const sensor_msgs::PointCloud2::ConstPtr& msg) {
  point_cloud_msg_ = msg;
  point_cloud_available = true;
}

void ConeDetectorHandle::run() {
  if(point_cloud_available) {
    coneDetector_.runAlgorithm(point_cloud_msg_);
    sendConeDetections();
    sendVisualization();
  }
}

void ConeDetectorHandle::sendConeDetections() {
  cone_detections_.cone_detections = coneDetector_.getConeDetections().cone_detections;
  cone_detections_.header.stamp = ros::Time::now();
  coneDetectionsPublisher.publish(cone_detections_);
  ROS_INFO("cone detections sent");
}

void ConeDetectorHandle::sendVisualization() {
  visualization_msgs::Marker marker;

  marker.type               = visualization_msgs::Marker::SPHERE_LIST;
  marker.action             = visualization_msgs::Marker::ADD;
  marker.id                 = 0;
  marker.scale.x            = 0.15;
  marker.scale.y            = 0.15;
  marker.scale.z            = 0.15;
  marker.header.stamp       = ros::Time::now();
  marker.header.frame_id    = "velodyne";
  marker.color.a            = 1.0;
  marker.color.r       = 0.0;
  marker.color.g       = 1.0;
  marker.color.b       = 0.0;

  for(auto& cone: cone_detections_.cone_detections) {
    geometry_msgs::Point p;
    p.x = cone.position.x;
    p.y = cone.position.y;
    marker.points.push_back(p);
  }

  coneMarkersPublisher.publish(marker);

}

}
