/*
    Formula Student Driverless Project (FSD-Project).
    Copyright (c) 2020:
     - Atharva Pusalkar <atharvapusalkar18@gmail.com>

    FSD-Project is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    FSD-Project is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with FSD-Project.  If not, see <https://www.gnu.org/licenses/>.
*/

#ifndef PERCEPTION_LIDAR_CONE_DETECTOR_HPP
#define PERCEPTION_LIDAR_CONE_DETECTOR_HPP

#include "fsd_common_msgs/ConeDetections.h"
#include "geometry_msgs/Point.h"
#include "std_msgs/String.h"
#include <sensor_msgs/PointCloud2.h>

#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_types.h>
#include <pcl/PCLPointCloud2.h>
#include <pcl/conversions.h>
#include <pcl_ros/transforms.h>
#include <pcl/visualization/cloud_viewer.h>

#include <pcl/filters/passthrough.h>

#include <pcl/common/angles.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/sample_consensus/sac_model_plane.h>


#include <pcl/filters/extract_indices.h>


#include <geometry_msgs/Pose.h>
#include <geometry_msgs/Vector3.h>
#include <pcl/PointIndices.h>
#include <pcl/common/angles.h>
#include <pcl/common/common.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/extract_clusters.h>

#include <shape_msgs/SolidPrimitive.h>
#include "visualization_msgs/Marker.h"

#include <boost/thread/thread.hpp>
#include <pcl/common/common_headers.h>
#include <pcl/visualization/pcl_visualizer.h>

#include <boost/thread/thread.hpp>
#include <pcl/common/common_headers.h>
#include <pcl/features/normal_3d.h>
#include <pcl/io/pcd_io.h>
#include <pcl/console/parse.h>

#include <cmath>


namespace ns_cone_detector {

    using Viewer = boost::shared_ptr<pcl::visualization::PCLVisualizer>;
    using Point = pcl::PointXYZI;
    using Cloud = pcl::PointCloud<Point>;
    using PointC = pcl::PointXYZRGB;
    using CloudC = pcl::PointCloud<PointC>;

    namespace PointClasses {
        static const int n_classes = 4;
        enum PointClass : u_char {
            inlier = 0,
            ground,
            too_high,
            too_far
        };

        static constexpr u_char colors[n_classes][3] = {
                {0  ,255,0  }, // green
                {0  ,0  ,255}, // blue
                {255,0  ,255}, // magenta
                {255,0  ,0  }  // red
        };
    };

    class ConeDescriptor{
    public:
        Cloud::Ptr cloud;
        Point mean, stddev;
        int count;
        double radius;
        bool valid;
        ConeDescriptor():
            cloud(new Cloud){
        }

        void calculate();
    };

    using Segmentation = std::vector<PointClasses::PointClass>;

    class Visualizer{
    public:
        boost::shared_ptr<pcl::visualization::PCLVisualizer> viewer;
        int v1 = 0;
        int v2 = 0;

        int point_size = 5;

        char* c1 = "original";
        char* c2 = "processed";

        Visualizer();

        void draw(Cloud::ConstPtr cloud, Cloud::ConstPtr cloud_out, Segmentation &segm, pcl::ModelCoefficients::Ptr plane_coefs, std::vector<ConeDescriptor> &cones);
    };

    class OutlierFilter{
    public:
        class Params{
        public:
            bool z_threshold_enable = true;
            float z_threshold_min = -0.5f;
            float z_threshold_max = 1.0f;
            Params(){}
        };

    protected:
        Params params;
        Visualizer vis;
    public:
        std::vector<ConeDescriptor> cones;

        OutlierFilter();

        void run(const sensor_msgs::PointCloud2::ConstPtr& msg);

    protected:
        void outlier_filter_impl(Cloud::Ptr &cloud_in, Cloud::Ptr &cloud_out);


        void SegmentConeInstances(Cloud::Ptr cloud_cones, std::vector<ConeDescriptor> &cones);
    };

    class ConeDetector {

    public:
        // Constructor
        ConeDetector();

        // Getters
        fsd_common_msgs::ConeDetections getConeDetections() const;

        /**
         *  creates the cone detections
         */
        void createConeDetections();

        /**
         * calls the other functions in the right order
         */
        void runAlgorithm(const sensor_msgs::PointCloud2::ConstPtr& msg);

    private:
      ros::Publisher marker_pub;
      OutlierFilter filter;
      fsd_common_msgs::ConeDetections coneDetections_;
    };
};

#endif //PERCEPTION_LIDAR_CONE_DETECTOR_HPP
