/*
    Formula Student Driverless Project (FSD-Project).
    Copyright (c) 2020:
     - Atharva Pusalkar <atharvapusalkar18@gmail.com>

    FSD-Project is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    FSD-Project is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with FSD-Project.  If not, see <https://www.gnu.org/licenses/>.
*/

#ifndef ESTIMATION_SLAM_SLAM_HPP
#define ESTIMATION_SLAM_SLAM_HPP

#include <eigen3/Eigen/Core>

#include <ros/ros.h>
#include "fsd_common_msgs/ConeDetections.h"
#include "fsd_common_msgs/CarStateDt.h"
#include "fsd_common_msgs/Map.h"
#include "geometry_msgs/Point.h"
#include "geometry_msgs/Pose2D.h"
#include "std_msgs/String.h"

namespace ns_slam {

class Jacobians;
class Particle;
class Landmark;

class Jacobians {
  public:
    Eigen::Vector2d zp;
    Eigen::MatrixXd Hv;
    Eigen::Matrix2d Hf;
    Eigen::Matrix2d Sf;

};

class Landmark {
  public:
    // COnstructor
    Landmark(Eigen::Vector2d x_init, Eigen::Matrix2d Q, std::string color_, Particle* particle);

    // Methods
    void update(Eigen::Vector2d z, Eigen::Matrix2d Q, std::string color_, Particle* particle);
    double pdf(const Eigen::Vector2d& z) const;
    double mahalanobis(const Eigen::Vector2d& z) const;

    std::string color;

    Eigen::Vector2d x;
    Eigen::Matrix2d P;
};

class Particle {
  public:
    // Constructor
    Particle(int n_particles);
    
    void predict(Eigen::Vector3d u, double dt);
    double computeWeight(int id, Eigen::Vector2d z, Eigen::Matrix2d Q);
    void proposalSampling(int id, Eigen::Vector2d z, Eigen::Matrix2d Q);

    double w;
    double x;
    double y;
    double yaw;

    Eigen::Matrix3d P;

    std::vector<Landmark> landmarks;
};

class Slam {

 public:
  // Constructor
  Slam();

  // Getters
  fsd_common_msgs::Map getMap() const;
  geometry_msgs::Pose2D getState() const;

  /**
   *  gets loop closure status
   */
  bool getLoopState();

  /**
   *  initializes the cone map
   */
  void initializeMap();

  /**
   *  initializes the state
   */
  void initializeState();

  /**
   *  updates the cone map
   */
  void updateMap(const fsd_common_msgs::ConeDetections &cones);

  /**
   *  updates the landmark map
   */
  void updateLandmarks(const fsd_common_msgs::ConeDetections &cones, bool frozen_update);

  /**
   *  Creates cone map based on landmarks
   */
  void createMap();

  /**
   *  calculates the new car state
   */
  void calculateState(const fsd_common_msgs::CarStateDt &velocity);

  /**
   *  calls the other functions in the right order
   */
  void runAlgorithm();

  /*
   * sets fastSLAM parameters
   */
  void setParameters(int n_particles, double mh_threshold);

  /*
   * Predict particles using motion model
   */
  void predictParticles(Eigen::Vector3d u, Eigen::Matrix3d R, double dt);

  /*
   * Normalizes particle weights
   */
  void normalizeWeight();

  /*
   * Resample using SIR filter
   */
  void resample();

  /*
   * Calculates final state of the particles
   */
  void calcFinalState();

  std::vector<Landmark> landmark_map_;
  std::vector<Particle> particles_;
  fsd_common_msgs::Map cone_map_;
  geometry_msgs::Pose2D slam_state_;
  int max_map_size_;

  int n_particles_;
  int n_resample_;
  double mh_threshold_;
  int best_id_ = 0;
};

double pi_2_pi(double angle);

Jacobians computeJacobians(Particle* particle, Eigen::Vector2d xf, Eigen::Matrix2d Pf, Eigen::Matrix2d Q_cov);



}

#endif //ESTIMATION_SLAM_SLAM_HPP
